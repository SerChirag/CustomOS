from optparse import OptionParser
print 'The Virtual Brain imported!'
def parse_args():
    parser = OptionParser()
    # parser.add_argument('--foo', help='Hello There')
    return parser.parse_args()
def main():
    print 'This is the main function :)'
    args = parse_args()
    print(args)

